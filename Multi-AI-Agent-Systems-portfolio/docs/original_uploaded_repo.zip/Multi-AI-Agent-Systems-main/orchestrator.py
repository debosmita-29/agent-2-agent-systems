from agents.schedule_agent import ScheduleAgent
from agents.school_agent import SchoolAgent
from agents.finance_agent import FinanceAgent
from agents.grocery_agent import GroceryAgent
from agents.health_agent import HealthAgent
from agents.travel_agent import TravelAgent
from agents.memory_agent import MemoryAgent

# Example of simple agent registry and routing logic
class Orchestrator:
    def __init__(self):
        self.agents = {
            "schedule": ScheduleAgent(),
            "school": SchoolAgent(),
            "finance": FinanceAgent(),
            "grocery": GroceryAgent(),
            "health": HealthAgent(),
            "travel": TravelAgent(),
            "memory": MemoryAgent(),
        }

    def route(self, task, **kwargs):
        agent_name = task.lower()
        agent = self.agents.get(agent_name)
        if agent:
            return agent.handle(**kwargs)
        return f"No agent found for task: {task}"

def orchestrator_main():
    orchestrator = Orchestrator()
    # Example: orchestrator.route("schedule", query="What events do I have this week?")
    print("Orchestrator initialized. Add your CLI or API here.")
