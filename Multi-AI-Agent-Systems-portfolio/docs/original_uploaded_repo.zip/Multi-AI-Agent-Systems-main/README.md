# Multi-AI-Agent-Systems

This repo implements a multi-agent AI system using [LangChain](https://github.com/langchain-ai/langchain) and NVIDIA-accelerated embeddings for Retrieval Augmented Generation (RAG) on local hardware. Each agent manages a domain (calendar, school, finance, etc.), coordinated by an Orchestrator, and powered by RAG memory with privacy by design.

## How It Works
- Each agent is a Python class in `agents/`, handling a life/task domain
- Orchestrator (`orchestrator.py`) routes tasks/questions to the right agent
- RAG-powered MemoryAgent uses a vector database with NVIDIA embedding models for persistent context
- All LLM and embedding processing runs locally (no cloud dependency)

## Key Agents
- ScheduleAgent: Calendar, reminders
- SchoolAgent: School updates
- FinanceAgent: Bills, subscriptions
- GroceryAgent: Inventory
- HealthAgent: Medicine, appointments
- TravelAgent: Trips, packing
- MemoryAgent: RAG memory (vector DB with NVIDIA embeddings)

See [skills/](skills/) for each agent's skills.

## NVIDIA Embedding Model & Vector DB
- Uses NVIDIA's GPU-accelerated embedding models (see `memory/vector_memory.py`)
- Demo code uses `nvidia_embeddings` (replace with real model/package if different)
- Vector search: In-memory demo (for full scale, use FAISS or Chroma with NVIDIA backend)

## Setup & Usage
1. Clone this repo
2. Install dependencies:  
   `pip install -r requirements.txt`
3. Set up/configure NVIDIA embedding model as in `memory/vector_memory.py`
4. Run local API/UI logic via `main.py` or add a CLI

**Note:** Swap the demo vector store with persistent Chroma/FAISS for scalability.

## Extending/Customizing
- Add further skills in `/skills` and logic in `/agents`
- Integrate third-party APIs (calendar, health, etc.) via agent `.handle` methods
- Improve memory agent with history, metadata, and semantic filters

---
Inspired by Debosmita Roy’s architecture for practical, real AI systems for life and business.
