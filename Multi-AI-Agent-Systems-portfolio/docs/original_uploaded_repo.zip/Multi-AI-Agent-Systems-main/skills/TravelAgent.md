# TravelAgent

Handles trip planning and packing checklist management.

## Example Usage
- Plan a new trip
- List required travel documents
- Generate a packing checklist

---

- **Class:** TravelAgent
- **Key Methods:** handle
