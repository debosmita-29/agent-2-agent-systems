# Agent Skills Index

## Agents and Skills

- **MemoryAgent**: Persistent memory, long-term retrieval
- **ScheduleAgent**: Calendar, reminders
- **SchoolAgent**: Assignments, school/work tracking
- **FinanceAgent**: Bills, subscriptions, budgets
- **GroceryAgent**: Grocery inventory
- **HealthAgent**: Medicine, appointments
- **TravelAgent**: Trip planning, packing checklists

See each skills/*.md for detailed instructions and API sample queries.
