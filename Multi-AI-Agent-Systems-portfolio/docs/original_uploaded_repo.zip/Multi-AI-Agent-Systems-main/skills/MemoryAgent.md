# MemoryAgent

## Purpose
Stores and retrieves context and persistent memory using RAG.

## Skills
- Store contextual data for long-term
- Retrieve specific info using semantic or keyword queries
- Power retrieval for other agents

## Example Usage
```
Recall last month's grocery purchases.
What was my dentist's advice last visit?
```