from memory.vector_memory import VectorMemory

class MemoryAgent:
    """Stores and retrieves context & persistent memory using RAG."""
    def __init__(self):
        self.memory = VectorMemory()
    def handle(self, **kwargs):
        mode = kwargs.get('mode', 'retrieve')
        query = kwargs.get('query', '')
        if mode == 'add':
            return self.memory.add(query)
        else:
            return self.memory.search(query)