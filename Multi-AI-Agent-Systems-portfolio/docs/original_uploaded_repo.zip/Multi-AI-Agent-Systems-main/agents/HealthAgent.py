class HealthAgent:
    """Handles medicine reminders and health appointments."""
    def __init__(self):
        pass
    def handle(self, query):
        """Stub: process health tasks (medicine reminders, appointments, etc.)"""
        return "HealthAgent: This is a health management stub."
